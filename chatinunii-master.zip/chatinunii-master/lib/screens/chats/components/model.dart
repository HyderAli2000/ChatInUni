class Booking {
  String date;
  Booking({required this.date});
}
