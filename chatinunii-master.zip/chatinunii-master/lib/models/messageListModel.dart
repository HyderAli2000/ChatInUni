import 'package:flutter/cupertino.dart';

class DatePicker {
  List msg;
  DatePicker({required this.msg});
}
